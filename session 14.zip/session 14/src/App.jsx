import ProfileCard from './components/ProfileCard.jsx'
import SocialLinks from './components/SocialLinks.jsx'
import ProjectCard from './components/ProjectCard.js'

const socials = [
  { platform: 'Instagram', url: 'https://instagram.com/' },
  { platform: 'LinkedIn', url: 'https://linkedin.com/' },
  { platform: 'GitHub', url: 'https://github.com/' },
]

const projects = [
  {
    title: 'Sunday Studio',
    description: 'A calm little identity and storefront for a neighborhood flower shop.',
    category: 'Brand & web',
    number: '01',
    color: 'peach',
  },
  {
    title: 'Field Notes',
    description: 'A pocket guide for finding good coffee and taking the scenic route.',
    category: 'Product design',
    number: '02',
    color: 'sage',
  },
  {
    title: 'Good Things Club',
    description: 'A cheerful collection of small rituals for a more thoughtful day.',
    category: 'Art direction',
    number: '03',
    color: 'lavender',
  },
]

function App() {
  return (
    <main className="page-shell">
      <header className="topbar">
        <a className="wordmark" href="#top" aria-label="InstaBio home">
          <span className="wordmark-mark">i.</span> instabio
        </a>
        <span className="topbar-note"><span className="status-dot" /> A tiny corner of the internet</span>
      </header>

      <section className="hero" id="top" aria-labelledby="intro-title">
        <div className="hero-copy">
          <p className="eyebrow"><span className="eyebrow-line" /> HELLO, I’M MAYA</p>
          <h1 id="intro-title">Making the internet feel a little more <em>human.</em></h1>
          <p className="hero-description">Designer, collector of nice things, and believer that the best ideas start with a good cup of tea.</p>
          <a className="text-link" href="#work">A few things I’ve made <span aria-hidden="true">↘</span></a>
        </div>

        <div className="profile-wrap">
          <span className="orbit orbit-one" aria-hidden="true" />
          <span className="orbit orbit-two" aria-hidden="true" />
          <span className="sparkle sparkle-one" aria-hidden="true">✳</span>
          <span className="sparkle sparkle-two" aria-hidden="true">✦</span>
          <ProfileCard
            name="Maya Chen"
            profilePictureUrl="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=480&q=85"
            bio="Independent designer making thoughtful brands and friendly digital things. Currently in Brooklyn, usually looking for a new bakery."
          >
            <SocialLinks links={socials} theme="dark" />
          </ProfileCard>
          <p className="profile-caption">Your new favorite internet neighbor <span aria-hidden="true">☺</span></p>
        </div>
      </section>

      <section className="work-section" id="work" aria-labelledby="work-title">
        <div className="section-heading">
          <div>
            <p className="eyebrow"><span className="eyebrow-line" /> A LITTLE SHOW & TELL</p>
            <h2 id="work-title">Some recent <em>favorites.</em></h2>
          </div>
          <p className="section-aside">A handful of projects made with<br />curiosity and care.</p>
        </div>
        <div className="project-grid">
          {projects.map((project) => <ProjectCard key={project.title} {...project} />)}
        </div>
      </section>

      <footer className="footer">
        <span>Made slowly, with a little sunshine <span aria-hidden="true">☼</span></span>
        <a href="mailto:hello@mayachen.design">Say hello <span aria-hidden="true">↗</span></a>
      </footer>
    </main>
  )
}

export default App
