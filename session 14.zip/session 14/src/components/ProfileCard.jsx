function ProfileCard({ name, profilePictureUrl, bio, children }) {
  return (
    <article className="profile-card" aria-label={`${name}'s profile`}>
      <div className="card-topline"><span className="card-brand"><span className="card-brand-icon">i.</span> instabio</span><span className="card-menu" aria-hidden="true">•••</span></div>
      <img className="profile-avatar" src={profilePictureUrl} alt={`${name} profile`} />
      <p className="profile-label">A PERSON, ON THE INTERNET</p>
      <h2 className="profile-name">{name}</h2>
      <p className="profile-bio">{bio}</p>
      {children}
      <p className="card-footnote"><span aria-hidden="true">✳</span> a little link to everywhere</p>
    </article>
  )
}

export default ProfileCard
