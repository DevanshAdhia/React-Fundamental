import { createElement as h } from 'react'

// Structure suggestion: build a reusable ProjectCard that accepts a title,
// description, category, number, and color as props, then renders them in an
// article with a visual preview and a clear project label.
function ProjectCard({ title, description, category, number, color = 'peach' }) {
  return (
    h('article', { className: 'project-card' },
      h('div', { className: `project-art project-art--${color}`, 'aria-hidden': 'true' },
        h('span', { className: 'project-art-number' }, number),
        h('span', { className: 'project-art-shape project-art-shape--one' }),
        h('span', { className: 'project-art-shape project-art-shape--two' }),
        h('span', { className: 'project-art-label' }, title),
        h('span', { className: 'project-art-sparkle' }, '✳'),
      ),
      h('div', { className: 'project-meta' },
        h('div', null,
          h('p', { className: 'project-category' }, category),
          h('h3', null, title),
        ),
        h('span', { className: 'project-open', 'aria-hidden': 'true' }, '↗'),
      ),
      h('p', { className: 'project-description' }, description),
    )
  )
}

export default ProjectCard
