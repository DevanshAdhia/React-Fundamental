const iconPaths = {
  Instagram: <><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle className="icon-fill" cx="18" cy="6" r="1" /></>,
  LinkedIn: <><path d="M5 9v10M5 5v.01M10 19v-6a4 4 0 0 1 8 0v6M10 10v9" /></>,
  GitHub: <><path d="M9 19c-4.3 1.4-4.3-2.5-6-3m12 6v-3.9a3.4 3.4 0 0 0-.9-2.7c3-.3 6.2-1.5 6.2-6.7a5.2 5.2 0 0 0-1.4-3.6 4.8 4.8 0 0 0-.1-3.6S17.6 1.2 15 3a13.2 13.2 0 0 0-7 0C5.4 1.2 3.2 1.5 3.2 1.5a4.8 4.8 0 0 0-.1 3.6 5.2 5.2 0 0 0-1.4 3.6c0 5.2 3.2 6.4 6.2 6.7A3.4 3.4 0 0 0 7 18.1V22" /></>,
}

function SocialLinks({ links = [], theme = 'light' }) {
  const appliedTheme = theme === 'dark' ? 'dark' : 'light'

  return (
    <nav className={`social-links social-links--${appliedTheme}`} aria-label="Social media links">
      {links.map(({ platform, url }) => (
        <a className="social-link" href={url} key={platform} target="_blank" rel="noreferrer" aria-label={`Visit ${platform}`}>
          <svg className="social-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
            {iconPaths[platform] ?? <circle cx="12" cy="12" r="8" />}
          </svg>
          <span>{platform}</span>
          <span className="social-arrow" aria-hidden="true">↗</span>
        </a>
      ))}
    </nav>
  )
}

export default SocialLinks
