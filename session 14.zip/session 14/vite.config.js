import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// ProjectCard.js intentionally keeps the requested .js filename while using JSX.
export default defineConfig({ plugins: [react({ include: /\.[jt]sx?$/ })] })
